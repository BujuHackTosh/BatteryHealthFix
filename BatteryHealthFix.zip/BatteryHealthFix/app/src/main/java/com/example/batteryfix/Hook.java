package com.example.batteryfix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.BufferedReader;
import java.io.FileReader;

public class Hook implements IXposedHookLoadPackage {
    // Used if system_server can't read sysfs (SELinux). Your phone's value.
    private static final int FALLBACK_DESIGN_UAH = 3588000;
    private static final String DESIGN_PATH = "/sys/class/power_supply/bms/charge_full_design";

    private static final int ID_FULL_MAH = 9001;
    private static final int ID_DESIGN_MAH = 9002;
    private static volatile int sFullMah = 0;
    private static volatile int sDesignMah = 0;
    private static volatile int sSoh = 0;
    private static volatile boolean sLoggedSohErr = false;
    private static volatile boolean sLoggedUfsErr = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if ("com.android.devicediagnostics".equals(lpp.packageName)) { hookDiagnostics(lpp); return; }
        if (!"android".equals(lpp.packageName)) return;
        try {
            Class<?> svc = XposedHelpers.findClass("com.android.server.BatteryService", lpp.classLoader);
            Class<?> hi = XposedHelpers.findClass("android.hardware.health.HealthInfo", lpp.classLoader);
            XposedHelpers.findAndHookMethod(svc, "update", hi, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try { patch(param.args[0]); } catch (Throwable t) { XposedBridge.log(t); }
                }
            });
            XposedBridge.log("BatteryHealthFix: hooked BatteryService.update");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: hook failed: " + t);
        }
        try {
            Class<?> reg = XposedHelpers.findClass(
                    "com.android.server.BatteryService$BatteryPropertiesRegistrar", lpp.classLoader);
            Class<?> bp = XposedHelpers.findClass("android.os.BatteryProperty", lpp.classLoader);
            int sohId;
            try {
                sohId = XposedHelpers.getStaticIntField(
                        XposedHelpers.findClass("android.os.BatteryManager", null),
                        "BATTERY_PROPERTY_STATE_OF_HEALTH");
            } catch (Throwable t) { sohId = 10; }
            final int id = sohId;
            XposedHelpers.findAndHookMethod(reg, "getProperty", int.class, bp, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        int pid = (Integer) param.args[0];
                        long val;
                        if (pid == ID_FULL_MAH) val = sFullMah;
                        else if (pid == ID_DESIGN_MAH) val = sDesignMah;
                        else if (pid == id) val = sSoh;
                        else return;
                        if (val <= 0) return;
                        XposedHelpers.callMethod(param.args[1], "setLong", val);
                        param.setResult(0);
                    } catch (Throwable t) { XposedBridge.log(t); }
                }
            });
            XposedBridge.log("BatteryHealthFix: hooked getProperty (soh id " + id + ")");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: getProperty hook failed: " + t);
        }
        try {
            Class<?> sms = XposedHelpers.findClass("com.android.server.StorageManagerService", lpp.classLoader);
            int n = XposedBridge.hookAllMethods(sms, "getInternalStorageRemainingLifetime", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Object r = param.getResult();
                        boolean need = !(r instanceof Integer && (Integer) r > 0);
                        int rem = need ? readStorageRemaining() : -1;
                        logRate("storage lifetime: original=" + r + " computed=" + rem);
                        if (need && rem > 0) param.setResult(rem);
                    } catch (Throwable t) { XposedBridge.log(t); }
                }
            }).size();
            XposedBridge.log("BatteryHealthFix: hooked storage lifetime (" + n + " methods)");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: storage hook failed: " + t);
        }
    }

    private static volatile boolean sLoggedDiag = false;

    private static void hookDiagnostics(XC_LoadPackage.LoadPackageParam lpp) {
        try {
            Class<?> base = XposedHelpers.findClass(
                    "com.android.settingslib.widget.UsageProgressBarPreference", lpp.classLoader);
            int n = XposedBridge.hookAllMethods(base, "onBindViewHolder", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (!param.thisObject.getClass().getName().endsWith("BatteryHealthPreference")) return;
                        android.view.View root =
                                (android.view.View) XposedHelpers.getObjectField(param.args[0], "itemView");
                        android.content.Context ctx = root.getContext();
                        int vid = ctx.getResources().getIdentifier("bottom_summary", "id", ctx.getPackageName());
                        android.widget.TextView tv = vid == 0 ? null
                                : (android.widget.TextView) root.findViewById(vid);
                        if (tv == null) {
                            if (!sLoggedDiag) { sLoggedDiag = true;
                                XposedBridge.log("BatteryHealthFix: bottom_summary view not found"); }
                            return;
                        }
                        android.os.BatteryManager bm =
                                (android.os.BatteryManager) ctx.getSystemService("batterymanager");
                        int full = bm.getIntProperty(ID_FULL_MAH);
                        int design = bm.getIntProperty(ID_DESIGN_MAH);
                        if (!sLoggedDiag) { sLoggedDiag = true;
                            XposedBridge.log("BatteryHealthFix: diag mAh " + full + " / " + design); }
                        if (full <= 0 || full > 100000 || design <= 0 || design > 100000) return;
                        String add = full + " / " + design + " mAh";
                        CharSequence cur = tv.getText();
                        if (cur != null && cur.toString().contains(add)) return;
                        tv.setText((cur == null ? "" : cur + "\n") + add);
                        tv.setVisibility(android.view.View.VISIBLE);
                    } catch (Throwable t) { XposedBridge.log(t); }
                }
            }).size();
            XposedBridge.log("BatteryHealthFix: hooked diagnostics bind (" + n + ")");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: diagnostics hook failed: " + t);
        }
    }

    private static volatile long sLastLog = 0;
    private static void logRate(String m) {
        long now = System.currentTimeMillis();
        if (now - sLastLog > 5000) { sLastLog = now; XposedBridge.log("BatteryHealthFix: " + m); }
    }

    private static final String UFS = "/sys/devices/platform/soc/1d84000.ufshc/health_descriptor/";

    // UFS life_time_estimation: 0x01 = 0-10% used ... 0x0A = 90-100% used, 0x0B = exceeded.
    // Returns the conservative remaining % (worst of A/B), or -1 if unreadable.
    private static int readStorageRemaining() {
        int worst = -1;
        for (String f : new String[]{"life_time_estimation_a", "life_time_estimation_b"}) {
            try (BufferedReader r = new BufferedReader(new FileReader(UFS + f))) {
                String v = r.readLine().trim();
                if (v.startsWith("0x")) v = v.substring(2);
                int lvl = Integer.parseInt(v, 16);
                if (lvl > worst) worst = lvl;
            } catch (Throwable t) {
                if (!sLoggedUfsErr) {
                    sLoggedUfsErr = true;
                    XposedBridge.log("BatteryHealthFix: cannot read UFS wear: " + t);
                }
            }
        }
        if (worst <= 0) {
            // Backup: boot script publishes the wear level as a system property.
            try {
                Object v = XposedHelpers.callStaticMethod(
                        XposedHelpers.findClass("android.os.SystemProperties", null),
                        "get", "debug.batteryfix.ufs_level");
                worst = Integer.parseInt(String.valueOf(v).trim());
                logRate("UFS level from property: " + worst);
            } catch (Throwable t) { worst = -1; }
        }
        if (worst <= 0) return -1;
        return Math.max(1, 100 - worst * 10);
    }

    private static void patch(Object info) throws Throwable {
        if (info == null) return;
        int design = XposedHelpers.getIntField(info, "batteryFullChargeDesignCapacityUah");
        if (design <= 0) {
            design = readInt(DESIGN_PATH);
            if (design <= 0) design = FALLBACK_DESIGN_UAH;
            XposedHelpers.setIntField(info, "batteryFullChargeDesignCapacityUah", design);
        }
        int full = XposedHelpers.getIntField(info, "batteryFullChargeUah");
        if (full <= 0 || design <= 0) return;

        // Compute first so the property hook works even if field writes fail.
        int soh = (int) Math.min(100L, (long) full * 100L / design);
        sSoh = soh;
        sFullMah = full / 1000;
        sDesignMah = design / 1000;

        try {
            Object hd = null;
            java.lang.reflect.Field hf = info.getClass().getField("batteryHealthData");
            hd = hf.get(info);
            if (hd == null) {
                hd = hf.getType().getDeclaredConstructor().newInstance();
                hf.set(info, hd);
            }
            java.lang.reflect.Field sf = hd.getClass().getField("batteryStateOfHealth");
            sf.setAccessible(true);
            if (sf.getType() == long.class) {
                if (sf.getLong(hd) <= 0) sf.setLong(hd, soh);
            } else {
                if (sf.getInt(hd) <= 0) sf.setInt(hd, soh);
            }
        } catch (Throwable t) {
            if (!sLoggedSohErr) {
                sLoggedSohErr = true;
                XposedBridge.log("BatteryHealthFix: SoH field write failed: " + t);
            }
        }
    }

    private static int readInt(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return Integer.parseInt(r.readLine().trim());
        } catch (Throwable t) {
            return -1;
        }
    }
}
