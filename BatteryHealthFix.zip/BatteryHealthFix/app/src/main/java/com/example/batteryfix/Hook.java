package com.example.batteryfix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.BufferedReader;
import java.io.FileReader;

public class Hook implements IXposedHookLoadPackage {
    // Used if system_server can't read sysfs (SELinux). Your phone's value.
    private static final int FALLBACK_DESIGN_UAH = 3588000;
    private static final String DESIGN_PATH = "/sys/class/power_supply/bms/charge_full_design";

    private static volatile int sSoh = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!"android".equals(lpp.packageName)) return;
        try {
            Class<?> svc = XposedHelpers.findClass("com.android.server.BatteryService", lpp.classLoader);
            Class<?> hi = XposedHelpers.findClass("android.hardware.health.HealthInfo", lpp.classLoader);
            XposedHelpers.findAndHookMethod(svc, "update", hi, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try { patch(param.args[0]); } catch (Throwable t) { XposedBridge.log(t); }
                }
            });
            XposedBridge.log("BatteryHealthFix: hooked BatteryService.update");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: hook failed: " + t);
        }
        try {
            Class<?> reg = XposedHelpers.findClass(
                    "com.android.server.BatteryService$BatteryPropertiesRegistrar", lpp.classLoader);
            Class<?> bp = XposedHelpers.findClass("android.os.BatteryProperty", lpp.classLoader);
            int sohId;
            try {
                sohId = XposedHelpers.getStaticIntField(
                        XposedHelpers.findClass("android.os.BatteryManager", null),
                        "BATTERY_PROPERTY_STATE_OF_HEALTH");
            } catch (Throwable t) { sohId = 10; }
            final int id = sohId;
            XposedHelpers.findAndHookMethod(reg, "getProperty", int.class, bp, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if ((Integer) param.args[0] != id || sSoh <= 0) return;
                        XposedHelpers.callMethod(param.args[1], "setLong", (long) sSoh);
                        param.setResult(0);
                    } catch (Throwable t) { XposedBridge.log(t); }
                }
            });
            XposedBridge.log("BatteryHealthFix: hooked getProperty (soh id " + id + ")");
        } catch (Throwable t) {
            XposedBridge.log("BatteryHealthFix: getProperty hook failed: " + t);
        }
    }

    private static void patch(Object info) throws Throwable {
        if (info == null) return;
        int design = XposedHelpers.getIntField(info, "batteryFullChargeDesignCapacityUah");
        if (design <= 0) {
            design = readInt(DESIGN_PATH);
            if (design <= 0) design = FALLBACK_DESIGN_UAH;
            XposedHelpers.setIntField(info, "batteryFullChargeDesignCapacityUah", design);
        }
        int full = XposedHelpers.getIntField(info, "batteryFullChargeUah");
        if (full <= 0) return;

        Object hd = XposedHelpers.getObjectField(info, "batteryHealthData");
        if (hd == null) {
            Class<?> t = info.getClass().getField("batteryHealthData").getType();
            hd = t.getDeclaredConstructor().newInstance();
            XposedHelpers.setObjectField(info, "batteryHealthData", hd);
        }
        if (XposedHelpers.getIntField(hd, "batteryStateOfHealth") <= 0) {
            int soh = (int) Math.min(100L, (long) full * 100L / design);
            XposedHelpers.setIntField(hd, "batteryStateOfHealth", soh);
        }
        sSoh = XposedHelpers.getIntField(hd, "batteryStateOfHealth");
    }

    private static int readInt(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return Integer.parseInt(r.readLine().trim());
        } catch (Throwable t) {
            return -1;
        }
    }
}
